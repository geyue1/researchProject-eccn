#!/usr/bin/env python

from distutils.core import setup

setup(
    name='SESN',
    version='0.0.1',
    description='Scale-Equivariant Steerable Networks',
    author='Ivan Sosnovik',
    author_email='i.sosnovik@uva.nl',
    packages=['models.impl'],
)
