#!/usr/bin/env python

from distutils.core import setup

setup(
    name='ScaleEqNet',
    version='0.0.1',
    description='Scale equivariance in CNNs with vector fields',
    author='Diego Marcos',
    author_email='diego.marcos@wur.nl',
    packages=['scaleEqNet'],
)
